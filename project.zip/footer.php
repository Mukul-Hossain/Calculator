</section>
<section>
                <div class="footer">
                    <h2><?php echo "I am a begginer" ?></h2>
                </div>
            </section>
    </div>
</body>

</html>