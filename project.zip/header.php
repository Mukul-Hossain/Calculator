<?php
$fonts = "lato";
$bgcolor = "#444";
$fontcolor = "red";
?>


<html lang="en">

<head>
    <title>PHP Trainig</title>
    <style>
        body {
            font-family: <?php echo $fonts; ?>
        }

        .phpmain {
            background: #ddd;
            width: 900px;
            margin: 0 auto;
            min-height: 700px;
            position: relative;
        }

        .footer,
        .header {
            background: <?php echo $bgcolor; ?>;
            color: <?php echo $fontcolor; ?>;
            padding: 5px 0;
            text-align:center;
            
        }

        .footer {
            position: absolute;
            width: 900px;
            bottom: 0;
        }

        .maincontent {
            display: block;
            margin: 0 auto;
            padding: 50px;
            text-align: center;
        }
        #myform{
            width: 700px;
            border: 2px solid #fff;
            padding: 50px;
        }
        input[type=number]{
            width: 200px;
            height: 40px;
            padding-left:10px;
            border-radius:10px;
            border: none;
            font-size: 20px;
        }
        input[type=submit]{
            cursor: pointer;
            width: 200px;
            height: 40px;
            background-color: blue;
            border: none;
            color:#fff
        }
        input[type=submit]:hover{
            background-color: teal;
        }
        select{
            width: 300px;
            height: 40px;
           
        }
    </style>
</head>

<body>
    <div class="phpmain">
        <section class="header">
            <h2>PHP Foundamental Training</h2>
           
        </section>
        <sectinon class="maincontent">
            