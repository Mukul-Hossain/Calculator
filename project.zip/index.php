<?php include 'header.php' ?>
<?php include 'calculator.php' ?>
<!--<script>
    function clickHere() {
        var getname = document.myform.name.value;
        document.getElementById('showname').innerHTML = getname;
    

    var genlength = document.myform.gender.length;
        for (i = 0; i < genlength; i++) {
            var checkgen = document.myform.gender[i].checked;
            if (checkgen) {
                genvalue = document.myform.gender[i].value;
            }
        }
        document.getElementById('showgen').innerHTML = genvalue;
    
    var checklength = document.myform.checkbox.length;
        for(i = 0; i < checklength; i++) {
            var checkcheckbox = document.myform.checkbox[i].checked;
            if (checkcheckbox) {
                checkvalue = document.myform.checkbox[i].value;
            }

        }
        document.getElementById('showcheckbox').innerHTML = checkvalue;
    

    var index = document.myform.select.selectedIndex;
        var selectvalue = document.myform.select.options[index].value;
        document.getElementById('showselect').innerHTML = selectvalue;
    }
</script>!-->


<form action="" method="post" id="myform">
    <label for="">Enter the first number</label><br>
    <input type="number" name="num1"><br><br>
    <label for="">Ener the second number</label><br>
    <input type="number" name="num2"><br><br>
    <input type="submit" name="calculation" value="Calculate"><br><br>

    <?php
if(isset($_POST['calculation'])){
    $nameOne= $_POST['num1'];
    $nameTwo= $_POST['num2'];
    if(empty($nameOne) or empty($nameTwo)){
        echo "<span style='color:red'>Field must not be empty.</span>";
    }else{
        echo "First Number is: ".$nameOne. " & Second Number is: ".$nameTwo. "<br>";
    $cal= new Calculation;
    $cal->add($nameOne, $nameTwo);
    $cal->sub($nameOne, $nameTwo);
    $cal->mul($nameOne, $nameTwo);
    $cal->div($nameOne, $nameTwo);
}
}
?>


</form>

<?php include 'footer.php'?>